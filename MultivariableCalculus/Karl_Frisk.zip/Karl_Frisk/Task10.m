%% Task10

f = @(x) 1./(1 + x).^2;

Integral_value = integral(f, 0, 1)

clear
