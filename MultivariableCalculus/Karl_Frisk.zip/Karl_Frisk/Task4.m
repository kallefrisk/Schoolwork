%% Task4

t = -2*pi:pi/250:2*pi;
x = sin(2*t);
y = cos(2*t);
z = sin(3*t);

plot3(x, y, z)

clear
