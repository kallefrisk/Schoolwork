%% Task2

r = 3;
theta = 0:pi/500:2*pi;
x = r*cos(theta);
y = r*sin(theta);

plot(x, y)
axis equal;

clear
