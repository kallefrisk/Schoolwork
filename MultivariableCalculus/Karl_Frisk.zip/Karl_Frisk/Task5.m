%% Task5

theta = 0:pi/500:4*pi;
r = 2;
x = r*cos(theta);
y = r*sin(theta);
z = theta/2/pi;

plot3(x, y, z)

clear
